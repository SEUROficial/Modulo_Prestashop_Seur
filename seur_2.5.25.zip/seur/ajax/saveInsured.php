<?php
// Deprecated: use modules/seur/controllers/front/saveinsured.php instead