<?php
// Deprecated: use modules/seur/controllers/front/getpickuppoints.php instead