<?php
// Deprecated: use modules/seur/controllers/front/getproducts.php instead
