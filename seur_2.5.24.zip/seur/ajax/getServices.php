<?php
// Deprecated: use modules/seur/controllers/front/getservices.php instead